//
//  Constants.swift
//  SantanderTech
//
//  Created by Elizeu RS on 07/06/19.
//  Copyright © 2019 elizeurs. All rights reserved.
//

import UIKit

let RED_BG = UIColor(red: 218/255, green: 1/255, blue: 1/255, alpha: 1).cgColor

