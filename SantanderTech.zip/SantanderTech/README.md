# SantanderTech
zup project / test

this is an app that i implemented a financial funds screen, that takes you to a second registration screen and finally one more, that confirms you are signedup.
for this project i've used alamofire, alamofireobjectmapper and swiftvalidator pods.
